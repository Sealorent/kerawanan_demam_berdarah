<?php

namespace App\Http\Controllers;

use App\Models\Rule;
use Illuminate\Http\Request;

class RuleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Rule::paginate(18);
        return view('backend.rule.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.rule.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $st = new Rule();
        $st->ch = $request->ch;
        $st->hh = $request->hh;
        $st->abj = $request->abj;
        $st->suhu = $request->suhu;
        $st->kelembaban = $request->kelembaban;
        $st->potensi = $request->potensi;
        $st->save();
        return redirect()->route('rule.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Rule::findOrFail($id);
        return view('backend.rule.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $up = Rule::findOrFail($id);
        $up->ch = $request->ch;
        $up->hh = $request->hh;
        $up->abj = $request->abj;
        $up->suhu = $request->suhu;
        $up->kelembaban = $request->kelembaban;
        $up->potensi = $request->potensi;
        $up->update();
        return redirect()->route('rule.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $up = Rule::findOrFail($id);
        $up->delete();
        return redirect()->route('rule.index');
    }
}
