<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-3">
                    <div class="card-header">
                        <div class="div d-flex justify-content-between">
                            <h5 class="card-tittle text-primary">Data Potensi <?php echo e($month." ".$reqyear); ?></h5>
                            <div class="d-flex  justify-content-end">
                                <form action="<?php echo e(route('potensi.index')); ?>" class="mx-2" method="get">
                                    <div class="input-group">
                                        <input type="text" name="year" id="datetimes" class="form-control " value=""
                                            placeholder="Pilih Periode">
                                        <select id="triwulan" name="triwulan"
                                            class="select2 form-select  <?php $__errorArgs = ['triwulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">--- Pilih triwulan ---</option>
                                            <?php $__currentLoopData = $triwulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( old('triwulan') == $key): ?>
                                            <option value="<?php echo e($key); ?>" selected><?php echo e($val['name']); ?>

                                            </option>
                                            <?php else: ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($val['name']); ?>

                                            </option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <button class="input-group-text" id="search" type="submit"> <i
                                                class="fa fa-search"></i></button>
                                    </div>
                                </form>
                                <a href="<?php echo e(route('potensi.create')); ?>" class="btn mb-3 mt-0 btn-primary">
                                    <span class="fa-solid fa-plus"></span>&nbsp;Tambah Data
                                </a>
                            </div>
                        </div>

                        <hr class="my-0" />
                    </div>
                    <!-- Account -->
                    <div class="card-body p-0">
                        <div class="card-body">
                            <div class="table-responsive text-nowrap">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class=" align-middle" rowspan="2">Kecamatan</th>
                                            <th class="text-center" colspan="3">Fuzzy </th>
                                            <th class="text-center align-middle" rowspan="2">Opsi</th>
                                            <th class="text-center align-middle" rowspan="2">rule</th>
                                        </tr>
                                        <tr>
                                            <th class=" text-center">Hasil </th>
                                            <th class="text-center">Potensi</th>
                                            <th class="text-center">Kasus</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!$data->isEmpty()): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $potensiFuzzy = \App\Models\Rule::select('potensi')->where('id',
                                        $item[0]['ruleFuzzy'])->pluck('potensi')[0];
                                        $kasus = \App\Models\Vektor::select('kasus_dbd')->where('id',
                                        $item[0]['id_vektor'])->pluck('kasus_dbd')[0];
                                        ?>
                                        <tr>
                                            <td><strong><?php echo e($item[0]['nama_kecamatan']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['hasilFuzzy']); ?> %</strong></td>
                                            <td class="text-center"><strong><?php echo e($potensiFuzzy); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($kasus); ?></strong></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('potensi.edit', $item[0]['id'])); ?>">
                                                    <button type="button" class="btn btn-primary btn-icon">
                                                        <i class="fa-solid fa-pencil"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('potensi.show', $item[0]['id'])); ?>">
                                                    <button type="button" class="btn btn-success btn-icon">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </a>
                                                <form action="<?php echo e(route('potensi.destroy', $item[0]['id'])); ?>"
                                                    method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" class="btn  btn-danger btn-icon">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>

                                            <td><?php echo e(\App\Models\Rule::select('ch',
                                                'hh','abj','hi')->where('id',$item[0]['ruleFuzzy'])->first()); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">Data Masih Kosong</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end">
                                    <?php echo e($data->links('vendor.pagination.custom')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Account -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extraJS'); ?>
<script type="text/javascript">
    $(function() {
        $('#datetimes').datepicker({
            autoclose: true,
            viewMode: 'years',
		     format: 'yyyy',
             minViewMode: "years",
            zIndexOffset : 999,
        });
    });
</script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
            icon: 'success',
            title: 'Sukses',
            text: "<?php echo e(session()->get('success')); ?>",
            type: "success"
        }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/data-potensi/potensi";
    }
    })
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
        icon: 'info',
        title: 'Mohon Maaf',
        text: '<?php echo e(session()->get('info')); ?>',
    }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/data-potensi/potensi";
    }
    })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Terjadi Kesalahan',
        text: '<?php echo e(session()->get('error')); ?>',
    })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\git\resources\views/backend/potensi/index.blade.php ENDPATH**/ ?>