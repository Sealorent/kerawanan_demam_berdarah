<?php $__env->startPush('extraCSS'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css"
    rel="stylesheet">
<style>
    .form-label #required {
        font-size: 1em;
        font-weight: bold;
        margin-bottom: 0;
        color: red;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <div class="d-flex align-items-start justify-content-between">
                            <h5 class="card-title text-primary">Tambah Kecamatan</h5>
                        </div>
                        <hr class="my-0" />
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('kecamatan.update', $data->id)); ?>" method="post">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group mb-3 col-md-6">
                                    <label for="kecamatan" class="form-label">Kecamatan <span
                                            id="required">*</span></label>
                                    <input type="text" class="form-control  <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kecamatan" value="<?php echo e($data->nama_kecamatan); ?>"
                                        placeholder="Masukkan Nama Kecamatan">
                                    <small class="text-primary">nb : Masukkan nama kecamatan dengan huruf kecil</small>
                                    <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mt-5">
                                    <button type="submit" class="btn btn-primary me-2">Simpan</button>
                                    <a class="btn btn-outline-secondary" href="<?php echo e(route('kecamatan.index')); ?>">Batal</a>
                                </div>
                        </form>
                        
                    </div>
                </div>
                <!-- /Account -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extraJS'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js">
</script>
<script type="text/javascript">
    $("#datepicker").datepicker(
		    {viewMode: 'years',
		     format: 'yyyy-mm',
             minViewMode: 1
	});
</script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: "<?php echo e(session()->get('success')); ?>",
                type: "success"
            }).then(function (result) {
        if (result.value) {
            window.location = "/admin-panel/data-master/kecamatan";
        }
        })
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
            icon: 'info',
            title: 'Mohon Maaf',
            text: '<?php echo e(session()->get('info')); ?>',
        }).then(function (result) {
        if (result.value) {
            window.location = "/admin-panel/data-master/kecamatan";
        }
        })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
            icon: 'error',
            title: 'Terjadi Kesalahan',
            text: '<?php echo e(session()->get('error')); ?>',
        })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\dbd-jember-laravel\resources\views/backend/kecamatan/edit.blade.php ENDPATH**/ ?>