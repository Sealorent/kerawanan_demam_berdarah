<?php $__env->startPush('extraCSS'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css"
    rel="stylesheet">
<style>
    .form-label #required {
        font-size: 1em;
        font-weight: bold;
        margin-bottom: 0;
        color: red;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <div class="d-flex align-items-start justify-content-between">
                            <h5 class="card-title text-primary">Tambah Tindakan</h5>
                        </div>
                        <hr class="my-0" />
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('tindakan.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                            <div class="form-group mb-3 col-md-3">
                                    <label class="form-label" for="kecamatan">Potensi<span id="required">*</span></label>
                                    <select id="potensi" name="potensi" class="select2 form-select  <?php $__errorArgs = ['potensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">--- Pilih Potensi ---</option>
                                        <option value="tinggi" <?php echo e(old('potensi') == 'tinggi' ? 'selected' : ''); ?> >Tinggi</option>
                                        <option value="sedang" <?php echo e(old('potensi') == 'sedang' ? 'selected' : ''); ?> >Sedang</option>
                                        <option value="rendah" <?php echo e(old('potensi') == 'rendah' ? 'selected' : ''); ?>>Rendah</option>
                                    </select>
                                    <?php $__errorArgs = ['potensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-3 col-md-9">
                                    <label for="ch" class="form-label">Tindakan <span id="required">*</span></label>
                                    <textarea type="text" class="form-control  <?php $__errorArgs = ['tindakan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tindakan" value="<?php echo e(old('tindakan')); ?>" placeholder="Masukkan Tindakan yang perlu dilakukan"></textarea>
                                    <?php $__errorArgs = ['tindakan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mt-5">
                                    <button type="submit" class="btn btn-primary me-2">Simpan</button>
                                    <a class="btn btn-outline-secondary" href="<?php echo e(route('tindakan.index')); ?>">Batal</a>
                                </div>
                            </div>
                        </form>
                        </div>
                </div>
                <!-- /Account -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extraJS'); ?>
<?php if(session('success')): ?>
<script>
    Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: "<?php echo e(session()->get('success')); ?>",
                type: "success"
            }).then(function (result) {
        if (result.value) {
            window.location = "/admin-panel/data-master/tindakan";
        }
        })
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
            icon: 'info',
            title: 'Mohon Maaf',
            text: '<?php echo e(session()->get('info')); ?>',
        }).then(function (result) {
        if (result.value) {
            window.location = "/admin-panel/data-master/tindakan";
        }
        })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
            icon: 'error',
            title: 'Terjadi Kesalahan',
            text: '<?php echo e(session()->get('error')); ?>',
        })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?> 

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BACKUP ME\git\resources\views/backend/tindakan/create.blade.php ENDPATH**/ ?>