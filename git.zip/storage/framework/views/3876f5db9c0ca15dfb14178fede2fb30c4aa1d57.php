<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="#" class="app-brand-link">
            <span class="app-brand-logo demo">
                <img src="<?php echo e(asset('assets/img/logo-jember.png')); ?>" width="40" height="40">
            </span>
            <span class="app-brand-text fw-bolder ms-2">DBD JEMBER</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>
    <hr>
    
    <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item <?php echo e(Request::segment(2) == 'dashboard' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons fa fa-home"></i>
                <div data-i18n="Analytics">Dashboard</div>
            </a>
        </li>
        <!-- <li class="menu-item  <?php echo e(Request::segment(2) == 'data-potensi' ? 'active  open' : ''); ?> ">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="User interface">Data Potensi</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php echo e(Request::segment(3) == 'potensi' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('potensi.index')); ?>" class="menu-link">
                        
                        <div data-i18n="Analytics">Potensi</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::segment(3) == 'klimatologi' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('klimatologi.index')); ?>" class="menu-link">
                        
                        <div data-i18n="Analytics">Klimatologi</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::segment(3) == 'vektor' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('vektor.index')); ?>" class="menu-link">
                        
                        <div data-i18n="Analytics">Dengue Vector</div>
                    </a>
                </li>
            </ul>
        </li>
        
        <li class="menu-item  <?php echo e(Request::segment(2) == 'data-master' ? 'active  open' : ''); ?> ">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="User interface">Data Master</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php echo e(Request::segment(3) == 'kecamatan' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('kecamatan.index')); ?>" class="menu-link">
                        <div data-i18n="Accordion">Data Kecamatan</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::segment(3) == 'rule' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('rule.index')); ?>" class="menu-link">
                        <div data-i18n="Accordion">Data Rule</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::segment(3) == 'kasus' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('kasus.index')); ?>" class="menu-link">
                        <div data-i18n="Accordion">Data Kasus</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::segment(3) == 'tindakan' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('tindakan.index')); ?>" class="menu-link">
                        <div data-i18n="Accordion">Data Tindakan</div>
                    </a>
                </li>
            </ul>
        </li> -->
        
        <li class="menu-item <?php echo e(Request::segment(3) == 'potensi' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('potensi.index')); ?>" class="menu-link">
                <i class="menu-icon fa fa-pie-chart"></i>
                <div data-i18n="Analytics">Data Potensi</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Request::segment(3) == 'kasus' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('kasus.index')); ?>" class="menu-link">
                <i class="menu-icon fa fa-users"></i>
                <div data-i18n="Analytics">Data Kasus</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Request::segment(3) == 'tindakan' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('tindakan.index')); ?>" class="menu-link">
                <i class="menu-icon tf-icons fa fa-ambulance"></i>
                <div data-i18n="Analytics">Data Tindakan</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Request::segment(2) == 'metode' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('metode')); ?>" class="menu-link">
                <i class="menu-icon tf-icons fa fa-tasks"></i>
                <div data-i18n="Analytics">Informasi Metode</div>
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH F:\BACKUP ME\git\resources\views/layouts/my-partials/sidebar.blade.php ENDPATH**/ ?>