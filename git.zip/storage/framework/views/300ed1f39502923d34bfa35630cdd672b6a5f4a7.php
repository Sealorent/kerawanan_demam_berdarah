<?php echo e($slot); ?>

<?php /**PATH F:\BACKUP ME\git\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>