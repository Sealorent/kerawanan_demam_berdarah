<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="div d-flex justify-content-between">
                            <h5 class="card-tittle text-primary">Data Klimatologi <?php echo e($month." ".$reqyear); ?></h5>
                            <div class="d-flex  justify-content-end">
                                <form action="<?php echo e(route('klimatologi.index')); ?>" class="mx-2 mb-3" method="get">
                                    <div class="input-group">
                                        <input type="text" name="year" id="datetimes" class="form-control " value=""
                                            placeholder="Pilih Periode">
                                        <select id="triwulan" name="triwulan"
                                            class="select2 form-select  <?php $__errorArgs = ['triwulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">--- Pilih triwulan ---</option>
                                            <?php $__currentLoopData = $triwulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php if( old('triwulan') == $key): ?>
                                            <option value="<?php echo e($key); ?>" selected><?php echo e($val['name']); ?>

                                            </option>
                                            <?php else: ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($val['name']); ?>

                                            </option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <button class="input-group-text" id="search" type="submit"> <i
                                                class="fa fa-search"></i></button>
                                    </div>
                                </form>
                                
                            </div>
                        </div>

                        <hr class="my-0" />
                    </div>
                    <!-- Account -->
                    <div class="card-body p-0">
                        <div class="card-body">
                            <div class="table-responsive text-nowrap">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Kecamatan</th>
                                            <th class="text-center">Temperatur</th>
                                            <th class="text-center">Kelembapan</th>
                                            <th class="text-center">Curah Hujan</th>
                                            <th class="text-center">Hari Hujan</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!$data->isEmpty()): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($item[0]['nama_kecamatan']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['temperatur']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['kelembapan']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['curah_hujan']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['hari_hujan']); ?></strong></td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">Data Masih Kosong</td>
                                        </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end">
                                    <?php echo e($data->links('vendor.pagination.custom')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Account -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extraJS'); ?>
<script type="text/javascript">
    $(function() {
        $('#datetimes').datepicker({
            autoclose: true,
            viewMode: 'years',
		     format: 'yyyy',
             minViewMode: "years",
            zIndexOffset : 999,
        });
});
</script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
            icon: 'success',
            title: 'Sukses',
            text: "<?php echo e(session()->get('success')); ?>",
            type: "success"
        }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/klimatologi";
    }
    })
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
        icon: 'info',
        title: 'Mohon Maaf',
        text: '<?php echo e(session()->get('info')); ?>',
    }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/klimatologi";
    }
    })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Terjadi Kesalahan',
        text: '<?php echo e(session()->get('error')); ?>',
    })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\git\resources\views/backend/klimatologi/index.blade.php ENDPATH**/ ?>