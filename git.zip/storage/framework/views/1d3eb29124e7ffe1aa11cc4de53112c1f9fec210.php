<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1  pt-3 pb-0">
    <div class="row">
        <div class="col-lg-12 col-md-12 order-1">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-3 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card"
                                        class="rounded" />
                                </div>
                                
                            </div>
                            <span>Jumlah Kecamatan</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-3 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card"
                                        class="rounded" />
                                </div>
                                

                            </div>
                            <span>Total Kasus</span>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-3 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/chart-success.png" alt="chart success"
                                        class="rounded" />
                                </div>
                                

                            </div>
                            <span>Jumlah Pemeriksaan Vektor</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-3 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card"
                                        class="rounded" />
                                </div>
                                

                            </div>
                            <span>Jumlah Pemeriksaan Perindukan</span>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container pt-1">
        <div class="row">
            <div class="col-lg-6 col-md-3">
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="d-flex align-items-start justify-content-between">
                            <h5>Data Kasus Demam Berdarah</h5>
                            <div class="input-group input-group-merge w-25">
                                <div class="input-group">
                                    <input type="text" id="date_kasus" class="datepicker form-control" name="date_kasus"
                                        value="<?php echo e(old('date_kasus',date('Y'))); ?>" placeholder="Tahun Data Demografi">
                                    <span class="input-group-text" id="text-to-speech-addon">
                                        <i class="fa fa-calendar date_kasus_icon"></i>
                                    </span>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="card-body">
                        <canvas id="lineChart"></canvas>
                        <div class="text-center emptyLineChart" hidden>
                            <p>Data Tahun Ini Tidak ada</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbditsco/dbd-its.com/resources/views/backend/dashboard/index.blade.php ENDPATH**/ ?>