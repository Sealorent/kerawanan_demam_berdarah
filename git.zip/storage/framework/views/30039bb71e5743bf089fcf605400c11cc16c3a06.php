<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="div d-flex justify-content-between">
                            <?php
                            $bulan = array ('Januari','Februari','Maret', 'April', 'Mei',
                            'Juni','Juli','Agustus','September','Oktober','November','Desember');
                            ?>
                            <h5 class="card-tittle text-primary">Data Kasus <?php echo e($bulan[(int)$month -1] . " ".
                                $year); ?></h5>
                            <div class="d-flex  justify-content-end">
                                <form action="<?php echo e(route('kasus.index')); ?>" class="mx-2 mb-3" method="get">
                                    <div class="input-group">
                                        <input type="text" name="date" id="datetimes" class="form-control " value=""
                                            placeholder="Pilih Periode" onchange="this.form.submit()">
                                        <button class="input-group-text" id="search" type="submit"> <i
                                                class="fa fa-search"></i></button>
                                    </div>
                                </form>
                                <a href="<?php echo e(route('kasus.create')); ?>" class="btn mb-3 mt-0 btn-primary">
                                    <span class="fa-solid fa-plus"></span>&nbsp;Tambah Data
                                </a>
                            </div>
                        </div>

                        <hr class="my-0" />
                    </div>
                    <!-- Account -->
                    <div class="card-body p-0">
                        <div class="card-body">
                            <div class="table-responsive text-nowrap">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Kecamatan</th>
                                            <th class="text-center">Jumlah Kasus</th>
                                            <th class="text-center">Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!$data->isEmpty()): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($item[0]['nama_kecamatan']); ?></strong></td>
                                            <td class="text-center"><strong><?php echo e($item[0]['total_kasus']); ?></strong></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('kasus.edit', $item[0]['id'])); ?>">
                                                    <button type="button" class="btn btn-primary btn-icon">
                                                        <i class="fa-solid fa-pencil"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('kasus.show', $item[0]['id'])); ?>">
                                                    <button type="button" class="btn btn-warning btn-icon">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </a>
                                                <form action="<?php echo e(route('kasus.destroy', $item[0]['id'])); ?>"
                                                    method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" class="btn  btn-danger btn-icon">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">Data Masih Kosong</td>
                                        </tr>
                                        <?php endif; ?>

                                        
                                </table>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Account -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extraJS'); ?>
<script type="text/javascript">
    $(function() {
        $('#datetimes').datepicker({
            autoclose: true,
            viewMode: 'yyyy-mm',
            format: 'yyyy-mm',
            minViewMode: 1,
            zIndexOffset : 99999999,
            orientation: "bottom",
    });

});
</script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
            icon: 'success',
            title: 'Sukses',
            text: "<?php echo e(session()->get('success')); ?>",
            type: "success"
        }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/data-master/kasus";
    }
    })
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
        icon: 'info',
        title: 'Mohon Maaf',
        text: '<?php echo e(session()->get('info')); ?>',
    }).then(function (result) {
    if (result.value) {
        window.location = "/admin-panel/data-master/kasus";
    }
    })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Terjadi Kesalahan',
        text: '<?php echo e(session()->get('error')); ?>',
    })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\git\resources\views/backend/kasus/index.blade.php ENDPATH**/ ?>